import pickle
import sys
import FPM.ImportFPM as fpm
# import FPM.ImportFPM as fpm
from TowMentat import *
from Vector import Vector
from Point import Point
from Mesh import *
import trimesh
import pyglet
import matplotlib as mpl
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import scipy as sp
from scipy import interpolate as ip
from geomdl import fitting as fit
from geomdl.visualization import VisMPL as vis

def main(plys, geom):
    
    # Initialise plot axis
    fig = plt.figure()
    ax = fig.add_subplot(111,projection='3d')

    # Initialise base mesh for offset
    base_stl = trimesh.load("/".join(["stl_files","panel" + ".stl"]))
    base_mesh = Mesh(base_stl)

    for p in plys:
        # Create new mesh to represent the tows on top
        top_mesh = Trimesh() 
        
        # Iterate through each tow
        for t in p.tows:
            t.ortho_offset(t.w) #Create offsets in transverse directions

            for i in range(len(t.new_pts)):
                # Interpolate between the points, with the target point distance being t.w/2
                # Where t.w = 3.25 currently.
                t.new_pts[i] = interpolate_tow_points(t.new_pts[i], t.w/2)
            t.get_new_normals()

            t_mesh = tow_mesh(t)
            top_mesh = top_mesh.__add__(t_mesh)

            tow_z_array, face_z_index = project_down(base_mesh, t)
            offset_rule(base_mesh, tow_z_array, face_z_index)
            base_mesh.adjust_z_off(face_z_index, tow_z_array)
            t.z_offset(tow_z_array)

            # plot_points(t.points, ax)
            plot_surface(t.new_pts[0],t.new_pts[-1], ax)
            # plot_offset(t.L,t.R, ax)

        # Current implementation: Ignore intraply overlaps, so project up against
        # whole ply instead of individual tows to avoid double counting
        base_vectors = project_up(base_mesh, top_mesh)

        # for v in base_vectors:
            # base_mesh.inc_z_off(v)
        
        base_mesh.visual(base_vectors)
    
    # top_mesh = top_mesh.__add__(base_mesh.mesh)
    
    plt.figure(fig.number)
    plt.show()
        
    m_plys = create_mentat_tows(plys)
    
    return m_plys

""" 
REDUNANT CLASS: Will remove
"""
def create_ply_index(m_tows):
    ply = {}
    for t in m_tows:
        if t[0].ply in ply.keys():
            ply[t[0].ply].append(t[0].name())
        else:
            ply[t[0].ply] = [t[0].name()]
    return ply


""" 
Create Marc/py_mentat compatible class
returns: PlyMentat(TowMentat(PointMentat)) classes
"""
def create_mentat_tows(plys):
    m_plys = []
    tow_idx = 1
    length = 100

    for p in plys:
        m_tows = []
        for t in p.tows:
            m_points = [[],[],[],[],[]]
            for i in range(len(t.new_pts[0])):
                for j in range(len(m_points)):
                    m_points[j].append(Point_Mentat(t.new_pts[j][i]))

            new_tow = Tow_Mentat(t._id, m_points, t.t, t.w, ply=t.ply)
            new_tow = batch_tows(new_tow, length)
            m_tows.append(new_tow)

        new_ply = Ply_Mentat(p._id, m_tows)
        m_plys.append(new_ply)

    return m_plys   

"""  
Batches TowMentat classes into batches containing $length number of poitns
This is to prevent Marc from crashing when passing in too many points
"""
def batch_tows(tow, length):
    if len(tow.pts[0]) < length:
        return [tow]

    batch = []
    i = 0
    while i + length < len(tow.pts):
        batch_tow = [[],[],[],[],[]]
        for j in range(len(batch_tow)):
            batch_tow[j] = tow.pts[j][i:i+length]
            
        new = Tow_Mentat(tow._id, batch_tow,tow.t,tow.w)
        batch.append(new)
        i += length - 1
    # Add remaining points from end of tow
    batch_tow = [[],[],[],[],[]]
    for j in range(len(batch_tow)):
        batch_tow[j] = tow.pts[j][i:]
    new = Tow_Mentat(tow._id, batch_tow,tow.t,tow.w)
    batch.append(new)

    return batch

""" 
Takes in array of points, and interpolates in between them using geomdl package
Interpoaltes to a level such that the distance between points is roughly equal to 
$target_length
Interpolates in batches, as large arrays can cause errors
"""
def interpolate_tow_points(points, target_length):
    
    # Batch up for large tows
    batch = []
    new_batch = []
    i = 0
    batch_sz = 100
    while(i + batch_sz < len(points)):
        batch.append(points[i:i+batch_sz])
        i += batch_sz -1
    batch.append(points[i:])

    for b in batch:
        if len(b) <= 2:     #If only two points - linear interpolation
            order = 1
        elif len(b) == 3:   #If 3 poits - quadratic interpolation
            order = 2
        else:               # if > 3 pts - cubic interpolation
            order = 3

        # get length of batch curve
        v1s = np.array(b[1:])
        v2s = np.array(b[:-1])
        diff = v2s - v1s
        length = sum([np.linalg.norm(x) for x in diff]) #Get total length of distances between each point
        
        # Delta dictates how many 'evenly' spaced points the interpolation funciton will output.
        # Roughly equal to 1/n_points-1 - (e.g. delta = 0.01 --> 1/100 --> 101 points).
        # Delta must be < 1, so min() statement is too ensure this (bit hacky atm)
        delta = min(target_length/length,0.99) 
        
        # call the interpolate curve function
        curve = fit.interpolate_curve(b,order)
        curve.delta = delta
        evalpts = curve.evalpts     #evalpts is the new list of interpolated points
        new_batch += evalpts        #stich batches back together as created
    
    # Evalpts is of type list, need to return as numpy array
    return np.array(new_batch)

""" 
Dump ply/tow data into pickle object
"""
def save_tows(obj, name):
    file_end = name + ".dat"
    file_name = '/'.join(['dat_files','batched',file_end])
    print(f"...saving at {file_name}")
    with open(file_name, 'wb') as f:
        pickle.dump(obj, f)
    print("save successful")



"""  
Plot spline, surface, points are all just different plot functions
Mainly used for debugging
"""
def plot_spline(tck):
    xn, yn = np.mgrid[-100:100:500j, -100:100:500j]
    zn = ip.bisplev(xn[:,0], yn[0,:], tck)

    plt.figure()
    plt.pcolor(xn, yn, zn)
    plt.colorbar()
    plt.show()

def plot_points(points, ax):
    #transform all coordinates
    coords = []
    for p in points:
        coords.append(p.coord.vec)

    axes = np.array(coords)
    xx = axes[:,0]
    yy = axes[:,1]
    zz = axes[:,2]

    ax.plot(xx, yy, zz) 
    # ax.scatter(xx, yy, zz) 

def plot_surface(L, R, ax):
    lx = np.array(L)
    rx = np.array(R)
    xx = np.vstack((lx[:,0], rx[:,0]))
    yy = np.vstack((lx[:,1], rx[:,1]))
    zz = np.vstack((lx[:,2], rx[:,2]))

    surf = ax.plot_surface(xx,yy,zz)

def plot_offset(L, R, ax):
    lx = np.array(L)
    rx = np.array(R)

    xx = lx[:,0]
    yy = lx[:,1]
    zz = lx[:,2]
    plot = ax.plot(xx,yy,zz)

    xx = rx[:,0]
    yy = rx[:,1]
    zz = rx[:,2]
    plot = ax.plot(xx,yy,zz)


if __name__ == '__main__':
    if len(sys.argv) is 1:
        exit("Specify file name to import")

    # Take in argument with geometry name (used for file lookup)
    geom = sys.argv[1]
    # Import the tow date
    plys = fpm.get_tows(geom)
    # get ply/tow/point data and manipulate accordingly
    marc_ply = main(plys, geom)

    save_tows(marc_ply, sys.argv[1])





    
